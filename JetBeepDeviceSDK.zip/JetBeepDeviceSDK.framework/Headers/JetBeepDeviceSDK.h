//
//  JetBeepDeviceSDK.h
//  JetBeepDeviceSDK
//
//  Created by Max Tymchii on 08.01.2020.
//  Copyright © 2020 JetBeep. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for JetBeepDeviceSDK.
FOUNDATION_EXPORT double JetBeepDeviceSDKVersionNumber;

//! Project version string for JetBeepDeviceSDK.
FOUNDATION_EXPORT const unsigned char JetBeepDeviceSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JetBeepDeviceSDK/PublicHeader.h>


