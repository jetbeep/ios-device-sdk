//
//  MerchantSDK.h
//  MerchantSDK
//
//  Created by Max Tymchii on 02.01.2020.
//  Copyright © 2020 JetBeep. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MerchantSDK.
FOUNDATION_EXPORT double MerchantSDKVersionNumber;

//! Project version string for MerchantSDK.
FOUNDATION_EXPORT const unsigned char MerchantSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MerchantSDK/PublicHeader.h>


